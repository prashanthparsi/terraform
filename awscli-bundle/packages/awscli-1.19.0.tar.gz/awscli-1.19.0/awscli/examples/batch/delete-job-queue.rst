**To delete a job queue**

This example deletes the GPGPU job queue.

Command::

  aws batch delete-job-queue --job-queue GPGPU
